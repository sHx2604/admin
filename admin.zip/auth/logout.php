<?php
require_once '../core/functions.php';

logout();
header('Location: login.php');
exit;
